
<?php 
        header('Location:login.php');
 ?>
 <meta charset="utf-8"/>